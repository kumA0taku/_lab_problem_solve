﻿namespace LotterPJ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stockLotto = new System.Windows.Forms.ListBox();
            this.checkBT = new System.Windows.Forms.Button();
            this.AddLottoBT = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.syncLotto = new System.Windows.Forms.Button();
            this.clearBT = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.qtLotto = new System.Windows.Forms.ComboBox();
            this.qtLottoList = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.totalPrice = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.total_price = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cal_total_price = new System.Windows.Forms.Button();
            this.check_lotto_list = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.selectLotto = new System.Windows.Forms.ComboBox();
            this.searchBT = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.buyBT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // stockLotto
            // 
            this.stockLotto.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockLotto.FormattingEnabled = true;
            this.stockLotto.ItemHeight = 36;
            this.stockLotto.Location = new System.Drawing.Point(216, 274);
            this.stockLotto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.stockLotto.Name = "stockLotto";
            this.stockLotto.Size = new System.Drawing.Size(150, 112);
            this.stockLotto.TabIndex = 0;
            this.stockLotto.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // checkBT
            // 
            this.checkBT.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBT.Location = new System.Drawing.Point(858, 257);
            this.checkBT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBT.Name = "checkBT";
            this.checkBT.Size = new System.Drawing.Size(134, 49);
            this.checkBT.TabIndex = 2;
            this.checkBT.Text = "ตรวจรางวัล";
            this.checkBT.UseVisualStyleBackColor = true;
            this.checkBT.Click += new System.EventHandler(this.button1_Click);
            // 
            // AddLottoBT
            // 
            this.AddLottoBT.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddLottoBT.Location = new System.Drawing.Point(512, 176);
            this.AddLottoBT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddLottoBT.Name = "AddLottoBT";
            this.AddLottoBT.Size = new System.Drawing.Size(83, 37);
            this.AddLottoBT.TabIndex = 8;
            this.AddLottoBT.Text = "Add";
            this.AddLottoBT.UseVisualStyleBackColor = true;
            this.AddLottoBT.Click += new System.EventHandler(this.AddLottoBT_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(210, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 36);
            this.label2.TabIndex = 9;
            this.label2.Text = "เลือกเลขที่ต้องการซื้อ";
            // 
            // syncLotto
            // 
            this.syncLotto.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.syncLotto.Location = new System.Drawing.Point(692, 372);
            this.syncLotto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.syncLotto.Name = "syncLotto";
            this.syncLotto.Size = new System.Drawing.Size(129, 52);
            this.syncLotto.TabIndex = 10;
            this.syncLotto.Text = "ดูเลขที่ซื้อ";
            this.syncLotto.UseVisualStyleBackColor = true;
            this.syncLotto.Click += new System.EventHandler(this.syncLotto_Click);
            // 
            // clearBT
            // 
            this.clearBT.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBT.Location = new System.Drawing.Point(18, 553);
            this.clearBT.Name = "clearBT";
            this.clearBT.Size = new System.Drawing.Size(99, 37);
            this.clearBT.TabIndex = 11;
            this.clearBT.Text = "Clear";
            this.clearBT.UseVisualStyleBackColor = true;
            this.clearBT.Click += new System.EventHandler(this.clearBT_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(409, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 36);
            this.label1.TabIndex = 12;
            this.label1.Text = "เลือกจำนวน";
            // 
            // qtLotto
            // 
            this.qtLotto.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtLotto.FormattingEnabled = true;
            this.qtLotto.Location = new System.Drawing.Point(415, 169);
            this.qtLotto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.qtLotto.Name = "qtLotto";
            this.qtLotto.Size = new System.Drawing.Size(61, 44);
            this.qtLotto.TabIndex = 13;
            // 
            // qtLottoList
            // 
            this.qtLottoList.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtLottoList.FormattingEnabled = true;
            this.qtLottoList.ItemHeight = 36;
            this.qtLottoList.Location = new System.Drawing.Point(415, 274);
            this.qtLottoList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.qtLottoList.Name = "qtLottoList";
            this.qtLottoList.Size = new System.Drawing.Size(61, 112);
            this.qtLottoList.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("TH Sarabun New", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(761, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(256, 49);
            this.label3.TabIndex = 15;
            this.label3.Text = "**ใบละ 80 บาทจ้าา**";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(506, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 36);
            this.label4.TabIndex = 16;
            this.label4.Text = "ราคา/ชุด";
            // 
            // totalPrice
            // 
            this.totalPrice.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPrice.FormattingEnabled = true;
            this.totalPrice.ItemHeight = 36;
            this.totalPrice.Location = new System.Drawing.Point(512, 274);
            this.totalPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.totalPrice.Name = "totalPrice";
            this.totalPrice.Size = new System.Drawing.Size(61, 112);
            this.totalPrice.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(210, 411);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 36);
            this.label5.TabIndex = 19;
            this.label5.Text = "รวม";
            // 
            // total_price
            // 
            this.total_price.AutoSize = true;
            this.total_price.Font = new System.Drawing.Font("TH Sarabun New", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_price.Location = new System.Drawing.Point(275, 402);
            this.total_price.Name = "total_price";
            this.total_price.Size = new System.Drawing.Size(70, 49);
            this.total_price.TabIndex = 20;
            this.total_price.Text = "      ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(351, 411);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 36);
            this.label7.TabIndex = 21;
            this.label7.Text = "บาท";
            // 
            // cal_total_price
            // 
            this.cal_total_price.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cal_total_price.Location = new System.Drawing.Point(415, 409);
            this.cal_total_price.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cal_total_price.Name = "cal_total_price";
            this.cal_total_price.Size = new System.Drawing.Size(80, 40);
            this.cal_total_price.TabIndex = 22;
            this.cal_total_price.Text = "รวมราคา";
            this.cal_total_price.UseVisualStyleBackColor = true;
            this.cal_total_price.Click += new System.EventHandler(this.cal_total_price_Click);
            // 
            // check_lotto_list
            // 
            this.check_lotto_list.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_lotto_list.FormattingEnabled = true;
            this.check_lotto_list.ItemHeight = 36;
            this.check_lotto_list.Location = new System.Drawing.Point(657, 208);
            this.check_lotto_list.Name = "check_lotto_list";
            this.check_lotto_list.Size = new System.Drawing.Size(180, 148);
            this.check_lotto_list.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(686, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 36);
            this.label6.TabIndex = 25;
            this.label6.Text = "รายการที่ซื้อ";
            // 
            // selectLotto
            // 
            this.selectLotto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectLotto.FormattingEnabled = true;
            this.selectLotto.Location = new System.Drawing.Point(216, 173);
            this.selectLotto.Name = "selectLotto";
            this.selectLotto.Size = new System.Drawing.Size(150, 37);
            this.selectLotto.TabIndex = 26;
            this.selectLotto.SelectedIndexChanged += new System.EventHandler(this.selectLotto_SelectedIndexChanged);
            // 
            // searchBT
            // 
            this.searchBT.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBT.Location = new System.Drawing.Point(216, 215);
            this.searchBT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchBT.Name = "searchBT";
            this.searchBT.Size = new System.Drawing.Size(92, 37);
            this.searchBT.TabIndex = 27;
            this.searchBT.Text = "Search";
            this.searchBT.UseVisualStyleBackColor = true;
            this.searchBT.Click += new System.EventHandler(this.searchBT_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(198, 30);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(366, 30);
            this.dateTimePicker1.TabIndex = 28;
            this.dateTimePicker1.Value = new System.DateTime(2022, 2, 1, 0, 0, 0, 0);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(167, 36);
            this.label8.TabIndex = 29;
            this.label8.Text = "รางวัลประจำวันที่:";
            // 
            // buyBT
            // 
            this.buyBT.Font = new System.Drawing.Font("TH Sarabun New", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buyBT.Location = new System.Drawing.Point(512, 409);
            this.buyBT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buyBT.Name = "buyBT";
            this.buyBT.Size = new System.Drawing.Size(95, 53);
            this.buyBT.TabIndex = 30;
            this.buyBT.Text = "สั่งซื้อ";
            this.buyBT.UseVisualStyleBackColor = true;
            this.buyBT.Click += new System.EventHandler(this.buyBT_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1180, 602);
            this.Controls.Add(this.buyBT);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.searchBT);
            this.Controls.Add(this.selectLotto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.check_lotto_list);
            this.Controls.Add(this.cal_total_price);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.total_price);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.totalPrice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.qtLottoList);
            this.Controls.Add(this.qtLotto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AddLottoBT);
            this.Controls.Add(this.clearBT);
            this.Controls.Add(this.syncLotto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkBT);
            this.Controls.Add(this.stockLotto);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "LOTTO_PJ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox stockLotto;
        private System.Windows.Forms.Button checkBT;
        private System.Windows.Forms.Button AddLottoBT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button syncLotto;
        private System.Windows.Forms.Button clearBT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox qtLotto;
        private System.Windows.Forms.ListBox qtLottoList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox totalPrice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label total_price;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button cal_total_price;
        private System.Windows.Forms.ListBox check_lotto_list;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox selectLotto;
        private System.Windows.Forms.Button searchBT;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buyBT;
    }
}

