﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LotterPJ
{
    public partial class Form1 : Form
    {
        string[] lotto_all = new string[]
        { "231546", "293890", "140833", "061904", "061921",
          "365421", "746586", "021788", "985314", "021354",
          "985874", "365421", "521020", "898732", "996443",
          "987465", "023145", "225588", "365441", "878694",
          "702130", "102350", "110235", "665321", "546632",
        };

        int[] lotto_all_int = new int[]
        { 231546,293890, 140833, 061904, 061921,
          365421, 746586, 021788, 985314, 021354,
          985874, 365421, 521020, 898732, 996443,
          987465, 023145, 225588, 365441, 878694,
          702130, 102350, 110235, 665321, 546632,
        };

        string[] lotto_rewards = new string[]
        //prize number
        { "521020", "102350", "345452", "487547", "813866",
          "485544", "059239", "111912", "365441", "021354",
        };

        string[] qt_list = new string[]
        //quantity list
        { "1", "2", "3", "4" };
        public Form1()
        {
            InitializeComponent();

            // select data first when run program
            selectLotto.Items.AddRange(lotto_all);
            selectLotto.Text = lotto_all[0];
            qtLotto.Items.AddRange(qt_list);
            qtLotto.Text = qt_list[0];
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //check reward BT
            string get_reward = " ";
            bool check_ = false;
            foreach ( string check_reward in check_lotto_list.Items )
            {
                if ( lotto_rewards.Contains(check_reward))
                {
                    check_ = true;
                    get_reward += check_reward + "  ";
                }
            }
            if(check_)
            MessageBox.Show("ยินดีด้วย คุณถูกรางวัล\n เลขที่ถูกรางวัลคือ" + get_reward, "ถูกรางวัล", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("เสียใจด้วย คุณไม่ถูกรางวัล", "ไม่ถูกรางวัล", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }


        private void AddLottoBT_Click(object sender, EventArgs e) //add lottory and quantity BT
        {
            /*
            string my_lotto = selectLotto.Text;
            stockLotto.Items.Add(my_lotto);
            */

            //string get_reward = " ";
           // bool check_2 = false;
            int i = 0;
            foreach (string check_lotto_num in lotto_all)
            {
                int cost = 0;
                if (selectLotto.SelectedItem == check_lotto_num)
                {
                    //quantity are you select * 80
                    cost = Convert.ToInt32(qtLotto.SelectedItem) * 80;

                    //add lottery/calulate of price/quantity are you select to listbox
                    stockLotto.Items.Add(selectLotto.SelectedItem);
                    totalPrice.Items.Add(cost);
                    qtLottoList.Items.Add(qtLotto.SelectedItem);
                }
                i++;
            }
            /*
            if (check_2)
                return;
            else
                MessageBox.Show("กรุณาเลือกรายการ!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            */

        }

        private void addLotto_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void syncLotto_Click(object sender, EventArgs e)
        {
            //sync data between 2 listbox
            check_lotto_list.Items.Clear();
            foreach (var text in stockLotto.Items)
                check_lotto_list.Items.Add(text);

            //check_lotto_list.SelectedIndex = -1;
        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void clearBT_Click(object sender, EventArgs e)
        {//clear botton
            stockLotto.Items.Clear();
            qtLottoList.Items.Clear();
            totalPrice.Items.Clear();
            check_lotto_list.Items.Clear();
            total_price.Text = String.Empty;
            MessageBox.Show("เคลียร์รายการของคุณเรียบร้อยแล้ว.", "สำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void cal_total_price_Click(object sender, EventArgs e)
        {//sum price of lottery
            if (stockLotto.Items.Count > 0)
            {
                int sum = 0;
                //loop for sum total price
                for (int i = 0; i < totalPrice.Items.Count; i++)
                {
                    sum += Convert.ToInt32(totalPrice.Items[i].ToString());
                }
                total_price.Text = Convert.ToString(sum);
            }
        }

        private void selectLotto_SelectedIndexChanged(object sender, EventArgs e)
        {// auto select lottery number 
            selectLotto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
            selectLotto.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            selectLotto.AutoCompleteSource = AutoCompleteSource.ListItems;
        }

        private void button1_Click_2(object sender, EventArgs e)
        {

        }

        private void searchBT_Click(object sender, EventArgs e)
        {//check search BT
            /*
            foreach (string check_lotto_num in selectLotto.Items)
            {
                if (lotto_all.Contains(check_lotto_num))
                {
                    //check_lotto_num = Convert.ToInt32(selectLotto.SelectedItem);
                    selectLotto.Text.Substring(check_lotto_num, 6-2);
                }
            }
            */
        }

        private void buyBT_Click(object sender, EventArgs e)
        {
            if (stockLotto.Items.Count > 0)
            {
                int sum = 0;
                for (int i = 0; i < totalPrice.Items.Count; i++)
                {
                    sum += Convert.ToInt32(totalPrice.Items[i].ToString());
                }
                total_price.Text = Convert.ToString(sum);
                MessageBox.Show("สั่งซื้อแล้ว", "ใบเสร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("กรุณาเลือกรายการก่อนสั่งซื้อ!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
