﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Switch_alphabet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string _text = textBox1.Text;
            char[] _char_array = _text.ToCharArray();
            Array.Reverse(_char_array);
            string _reverse_text = string.Empty;
            for (int i = 0; i <= _char_array.Length - 1; i++)
            {
                _reverse_text += _char_array.GetValue(i);
            }
            MessageBox.Show(_reverse_text);
        }
    }
}
