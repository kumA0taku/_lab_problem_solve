﻿namespace ReverseString
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.inputBox = new System.Windows.Forms.TextBox();
            this.outputBox = new System.Windows.Forms.TextBox();
            this.reverseBotton = new System.Windows.Forms.Button();
            this.clearBotton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Browallia New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "ข้อความต้นฉบับ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Browallia New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "ข้อความแบบย้อนกลับ";
            // 
            // inputBox
            // 
            this.inputBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputBox.Location = new System.Drawing.Point(202, 56);
            this.inputBox.Name = "inputBox";
            this.inputBox.Size = new System.Drawing.Size(377, 29);
            this.inputBox.TabIndex = 2;
            // 
            // outputBox
            // 
            this.outputBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputBox.Location = new System.Drawing.Point(202, 117);
            this.outputBox.Name = "outputBox";
            this.outputBox.Size = new System.Drawing.Size(377, 29);
            this.outputBox.TabIndex = 3;
            // 
            // reverseBotton
            // 
            this.reverseBotton.BackColor = System.Drawing.Color.LimeGreen;
            this.reverseBotton.Font = new System.Drawing.Font("Browallia New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reverseBotton.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.reverseBotton.Location = new System.Drawing.Point(291, 200);
            this.reverseBotton.Name = "reverseBotton";
            this.reverseBotton.Size = new System.Drawing.Size(131, 57);
            this.reverseBotton.TabIndex = 4;
            this.reverseBotton.Text = "กลับข้อความ";
            this.reverseBotton.UseVisualStyleBackColor = false;
            this.reverseBotton.Click += new System.EventHandler(this.reverseBotton_Click);
            // 
            // clearBotton
            // 
            this.clearBotton.BackColor = System.Drawing.Color.Red;
            this.clearBotton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBotton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.clearBotton.Location = new System.Drawing.Point(544, 285);
            this.clearBotton.Name = "clearBotton";
            this.clearBotton.Size = new System.Drawing.Size(118, 42);
            this.clearBotton.TabIndex = 5;
            this.clearBotton.Text = "Clear data";
            this.clearBotton.UseVisualStyleBackColor = false;
            this.clearBotton.Click += new System.EventHandler(this.clearBotton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.IndianRed;
            this.ClientSize = new System.Drawing.Size(674, 339);
            this.Controls.Add(this.clearBotton);
            this.Controls.Add(this.reverseBotton);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.inputBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "โปรแกรมกลับข้อความ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputBox;
        private System.Windows.Forms.TextBox outputBox;
        private System.Windows.Forms.Button reverseBotton;
        private System.Windows.Forms.Button clearBotton;
    }
}

