﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SequentialSearch
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[5] { 1, 2, 3, 4, 5 };
            Console.Write("Enter a number to search for: ");
            int searchNumber = Convert.ToInt32(Console.ReadLine());

            bool found = SeqSearch(numbers, searchNumber);

            if (found)
                Console.WriteLine(searchNumber + " is in the array.");
            else
                Console.WriteLine(searchNumber + " is not in the array.");


            int _min = FindMin(numbers);
            Console.WriteLine("Min number is "+_min);
            int _max = FindMax(numbers);
            Console.WriteLine("Max number is " +  _max);
            /*
            int _min = FindMin(numbers);
            Console.WriteLine(_min);
            int _max = FindMax(numbers);
            Console.WriteLine(_max);*/
        }

        static bool SeqSearch(int[] arr, int sValue)
        {
            for(int index = 0; index < arr.Length; index++)
                if(arr[index] == sValue)
                    return true;
            return false;

        }
        static int FindMin(int[] arr)
        {
            int min = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] <= min)
                {
                    min = arr[i];
                }
            }
            return min;
        }
        static int FindMax(int[] arr)
        {
            int max = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] >= max)
                {
                    max = arr[i];
                }
            }
            return max;
        }

        /* by Tae Nontakorn
        static int FindMin(int[] arr)
        {
            int min = 9999999;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < min)
                {
                    min = arr[i];
                }
            }
            return min;
        }
        static int FindMax(int[] arr)
        {
            int max = -9999999;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] > max)
                {
                    max = arr[i];
                }
            }
            return max;
        }*/
    }
}
