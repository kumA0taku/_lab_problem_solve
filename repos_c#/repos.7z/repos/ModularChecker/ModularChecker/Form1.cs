﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModularChecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //textBox2, textBox1
            int num1 = int.Parse(textBox1.Text);
            int num2 = int.Parse(textBox2.Text);
            if (checkMod(num1, num2))
                MessageBox.Show(num1 + " เป็นผลคูณของ " + num2 + " เนื่องจาก " + num2 + " คูณกับตัวเลขใดๆแล้วมีค่าเท่ากับ " + num1);
            else
                MessageBox.Show(num1 + " ไม่เป็นผลคูณของ " + num2 + " เนื่องจาก " + num2 + " ไม่สามารถคูณกับตัวเลขใดๆแล้วมีค่าเท่ากับ " + num1 );
        }
        public Boolean checkMod(int a, int b)
        {
            return a%b==0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
