﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalGPA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            float _num1 = float.Parse(textBox1.Text); 
            float _num2 = float.Parse(textBox2.Text);
            float _point = _num1 + _num2;
            if (_point <= 100 && _point >= 80) { MessageBox.Show("Your GPA is A"); }
            else if (_point <= 79 && _point >= 70) { MessageBox.Show("Your GPA is B"); }
            else if (_point <= 69 && _point >= 60) { MessageBox.Show("Your GPA is C"); }
            else if (_point <= 59 && _point >= 50) { MessageBox.Show("Your GPA is D"); }
            else if (_point <= 49 && _point >= 0) { MessageBox.Show("Your GPA is F"); }
            else { MessageBox.Show("N"); }
        }
    }
}
